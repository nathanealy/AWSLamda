#config file
hcaptcha_address = "https://hcaptcha.com/siteverify"
hcaptcha_secret = "0x77248D42D74f302127A8556FA2EAd820FC3cCF05"