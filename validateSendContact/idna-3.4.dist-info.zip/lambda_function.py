import json
import logging
import requests
import config

# log settings
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # TODO implement

    try:
        emailaddress = event['emailaddress']
        messagebody = event['messagebody']
        hcaptcharepsonse = event['hcaptcharepsonse']

        if len(emailaddress) > 0 and len(messagebody) > 0 and len(hcaptcharepsonse) > 0:

            if validatehCaptcha(hcaptcharepsonse) == "OK":
                logger.info("hCaptcha validated")
                if sendMessage(emailaddress, messagebody) == "OK":
                    logger.info("Message sent")
                    return {
                        'statusCode': 200,
                        'body': json.dumps('OK')
                    }      
                else:
                    logger.info("hCaptcha not validated")
                    return {
                        'statusCode': 500,
                        'body': json.dumps('ERROR')
                    }  
            else:
                return {
                    'statusCode': 500,
                    'body': json.dumps('ERROR')
                }                         
        else:
            return {
                'statusCode': 204,
                'body': json.dumps('NULL parameter(s)')
            }             
    except:
        logger.error("ERROR: Getting parameters")
        return {
            'statusCode': 500,
            'body': json.dumps('Error')
        }                
       
def validatehCaptcha(hrepsonse):
    status = "OK"
    pool = ""
    url = ""
    message = ""
    
    logger.info('validatehCaptcha i') 

    logger.info('SECRET ' + config.hcaptcha_secret) 
    logger.info('RESPONSE ' + hrepsonse) 
    logger.info('ADDRESS ' + config.hcaptcha_address) 
        
    data = {'secret': config.hcaptcha_secret, 'respone': hrepsonse}

    try:
        logger.info('validatehCaptcha ii') 
    
        response = requests.post(config.hcaptcha_address,data=data,headers={'Content-Type':'application/x-www-form-urlencoded'})
        json_response = response.json()
        logger.info('validatehCaptcha iii') 
        logger.info(response)  
        logger.info(json_response)          
    except:
        status = "ERROR" 
        logger.error('GeneralError')
        
    return status

def sendMessage(address, message):
    status = "OK"

    return status