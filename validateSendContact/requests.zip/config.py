#config file
hcaptcha_address = "https://hcaptcha.com/siteverify"
hcaptcha_secret = "0x77248D42D74f302127A8556FA2EAd820FC3cCF05"
ses_iam_user_name = "ses-smtp-user.20230105-225344"
ses_smtp_user_name = "AKIAXEZG7CNNM64VABOR"
ses_smtp_password = "BOqRU2LhOcY3YS8zJRfmlxlVuJsgZs7RjA1j8PXp9gQS"
aws_region = "us-east-2"