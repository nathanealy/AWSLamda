#config file containing credentials for RDS MySQL instance
db_username = "wjrangers"
db_password = "IlivedinGraysville1!"
db_name = "tsr_schema"
db_host = "wjr.ci59nzg7msqk.us-east-2.rds.amazonaws.com"
db_port = 3306